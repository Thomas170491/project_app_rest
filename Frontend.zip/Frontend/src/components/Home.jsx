import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Welcome to RideShare App</h1>
      <p>The fastest and most reliable VTC booking app.</p>
    </div>
  );
};

export default Home;