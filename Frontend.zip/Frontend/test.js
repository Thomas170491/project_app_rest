import { loginUser } from 'src/components/api'

console.log(loginUser('testuser', 'testpassword'))